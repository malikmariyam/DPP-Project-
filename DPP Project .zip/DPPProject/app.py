import streamlit as st
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
import plotly.express as px
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.svm import SVC
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, confusion_matrix, roc_curve, roc_auc_score
from imblearn.over_sampling import SMOTE
from xgboost import XGBClassifier

# Streamlit App Customization: Theme & Background
st.set_page_config(
    page_title="Stroke Prediction Analysis",
    page_icon="🧠",
    layout="wide",
    initial_sidebar_state="expanded",
)
st.markdown(
    """
    <style>
    /* Background with right alignment */
    .stApp {
        background: url("https://media.istockphoto.com/id/1415185434/vector/doctor-helping-elder-patients-with-alzheimer-disease-senior-care-and-assistance-concept.jpg?s=612x612&w=0&k=20&c=-ztPKrT93I7rUpnRRA6UqIEQyMTnalo3jCTjtklngt8=");
        background-size: auto;
        background-repeat: no-repeat;
        background-attachment: fixed;
        background-position: right;
    }
    /* Sidebar Styling */
    .css-1d391kg {
        background-color: #2b2d42;
    }
    .css-1d391kg h2 {
        color: white;
    }
    /* Button Styling */
    .stButton>button {
        background-color: #4CAF50;
        color: white;
        border-radius: 5px;
        padding: 10px 20px;
        font-size: 16px;
    }
    .stButton>button:hover {
        background-color: #45a049;
    }
    /* Fonts */
    h1, h2, h3, p {
        font-family: 'Arial', sans-serif;
    }
    </style>
    """,
    unsafe_allow_html=True,
)

# Load Data Function
@st.cache_data
def load_data(uploaded_file):
    df = pd.read_csv(uploaded_file)
    df.drop(["id"], axis=1, inplace=True, errors="ignore")
    df.drop(df[df["gender"] == "Other"].index, axis=0, inplace=True)
    df.drop(df[df["smoking_status"] == "Unknown"].index, axis=0, inplace=True)
    df["smoking_status"] = df["smoking_status"].replace({"formerly smoked": "smokes"})
    df["bmi"] = df["bmi"].fillna(df["bmi"].mean())
    return df

# Preprocessing Function
def preprocess_data(df, num_features, cat_features):
    scaler = StandardScaler()
    encoder = OneHotEncoder(handle_unknown="ignore")
    transformer = ColumnTransformer(
        [("scale", scaler, num_features), ("encode", encoder, cat_features)]
    )
    X = transformer.fit_transform(df)
    return X, df["stroke"]

# App Layout
st.title("Stroke Prediction Analysis 🧠")

# File Upload
uploaded_file = st.file_uploader("Upload your CSV file 📄", type=["csv"])

if uploaded_file:
    df = load_data(uploaded_file)

    # Sidebar Navigation
    st.sidebar.header("📑 Navigation")
    sections = ["Data Exploration", "Preprocessing", "Model Training", "Evaluation"]
    selected_section = st.sidebar.radio("Go to", sections)

    # Data Exploration Section
    if selected_section == "Data Exploration":
        st.markdown("<h2 style='color: #4CAF50;'>Data Exploration 🔍</h2>", unsafe_allow_html=True)

        col1, col2 = st.columns([2, 1])
        with col1:
            st.write("<p style='font-size:18px;'>Dataset Preview:</p>", unsafe_allow_html=True)
            st.write(df.head())

        with col2:
            fig = px.pie(df, names="gender", title="Gender Distribution")
            st.plotly_chart(fig, use_container_width=True)

        st.subheader("Numerical Features 📊")
        for col in df.select_dtypes(exclude="object").columns:
            fig = px.histogram(df, x=col, title=f"{col} Distribution")
            st.plotly_chart(fig, use_container_width=True)

    # Preprocessing Section
    elif selected_section == "Preprocessing":
        st.markdown("<h2 style='color: #4CAF50;'>Data Preprocessing ⚙️</h2>", unsafe_allow_html=True)

        cat_features = ["gender", "ever_married", "work_type", "smoking_status"]
        num_features = ["age", "avg_glucose_level", "bmi"]

        X, y = preprocess_data(df, num_features, cat_features)
        st.write("Preprocessed Features (first 5 rows):")
        st.write(X[:5])

    # Model Training Section
    elif selected_section == "Model Training":
        st.markdown("<h2 style='color: #4CAF50;'>Model Training 🏋️‍♀️</h2>", unsafe_allow_html=True)

        cat_features = ["gender", "ever_married", "work_type", "smoking_status"]
        num_features = ["age", "avg_glucose_level", "bmi"]

        X, y = preprocess_data(df, num_features, cat_features)
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)

        smote = SMOTE(random_state=42)
        X_train, y_train = smote.fit_resample(X_train, y_train)

        models = {
            "Logistic Regression": LogisticRegression(max_iter=1000),
            "Decision Tree": DecisionTreeClassifier(),
            "Random Forest": RandomForestClassifier(),
            "SVC": SVC(probability=True),
            "XGBoost": XGBClassifier(eval_metric="logloss"),
        }

        results = {}
        for name, model in models.items():
            model.fit(X_train, y_train)
            results[name] = {
                "Train Accuracy": model.score(X_train, y_train),
                "Test Accuracy": model.score(X_test, y_test),
            }

        st.write("Model Performance:")
        st.write(pd.DataFrame(results).T)

    # Evaluation Section
    elif selected_section == "Evaluation":
        st.markdown("<h2 style='color: #4CAF50;'>Model Evaluation 📊</h2>", unsafe_allow_html=True)

        cat_features = ["gender", "ever_married", "work_type", "smoking_status"]
        num_features = ["age", "avg_glucose_level", "bmi"]

        X, y = preprocess_data(df, num_features, cat_features)
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)

        model = LogisticRegression(max_iter=1000)
        model.fit(X_train, y_train)

        y_pred = model.predict(X_test)

        st.subheader("Confusion Matrix")
        cm = confusion_matrix(y_test, y_pred)
        fig = plt.figure(figsize=(6, 4))
        sns.heatmap(cm, annot=True, fmt="d", cmap="Blues", cbar=False)
        st.pyplot(fig)

        st.subheader("Classification Report")
        st.text(classification_report(y_test, y_pred))

        prob = model.predict_proba(X_test)[:, 1]
        fpr, tpr, _ = roc_curve(y_test, prob)
        auc_score = roc_auc_score(y_test, prob)

        fig, ax = plt.subplots(figsize=(6, 4))
        ax.plot(fpr, tpr, label=f"AUC = {auc_score:.2f}", color="purple")
        ax.set_xlabel("False Positive Rate")
        ax.set_ylabel("True Positive Rate")
        ax.legend(loc="best")
        st.pyplot(fig)

else:
    st.warning("⚠️ Please upload a CSV file to proceed.")